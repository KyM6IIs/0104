﻿using System;

namespace NumberBaseCalculator
{
    class Program
    {
        static void Main(string[] args)
        {

            while (true)
            {
                try
                {
                    Console.Write("Введите исходную систему счисления (2-36): ");
                    int fromBase = int.Parse(Console.ReadLine());

                    if (fromBase < 2 || fromBase > 36)
                    {
                        Console.WriteLine("Ошибка! Система счисления должна быть от 2 до 36.\n");
                        continue;
                    }

                    Console.Write($"Введите число в {fromBase}-й системе: ");
                    string number = Console.ReadLine().ToUpper();
                    if (!IsValidNumber(number, fromBase))
                    {
                        Console.WriteLine("Ошибка! Число содержит недопустимые символы для данной системы счисления.\n");
                        continue;
                    }
                    Console.Write("Введите целевую систему счисления (2-36): ");
                    int toBase = int.Parse(Console.ReadLine());

                    if (toBase < 2 || toBase > 36)
                    {
                        Console.WriteLine("Ошибка! Система счисления должна быть от 2 до 36.\n");
                        continue;
                    }
                    string result = ConvertBase(number, fromBase, toBase);

                    Console.WriteLine($"\nРезультат: {number} ({fromBase}) = {result} ({toBase})\n");

                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка! Введите корректное число.\n");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка! {ex.Message}\n");
                }

                Console.Write("Хотите продолжить? (y/n): ");
                string choice = Console.ReadLine().ToLower();
                if (choice != "y" && choice != "yes")
                {
                    break;
                }
                Console.WriteLine();
            }

            Console.WriteLine("\nПрограмма завершена. Нажмите любую клавишу для выхода...");
            Console.ReadKey();
        }

        static bool IsValidNumber(string number, int baseSystem)
        {
            foreach (char c in number)
            {
                int value = CharToValue(c);
                if (value < 0 || value >= baseSystem)
                {
                    return false;
                }
            }
            return true;
        }

        static int CharToValue(char c)
        {
            if (c >= '0' && c <= '9')
            {
                return c - '0';
            }
            else if (c >= 'A' && c <= 'Z')
            {
                return c - 'A' + 10;
            }
            return -1;
        }

        static char ValueToChar(int value)
        {
            if (value >= 0 && value <= 9)
            {
                return (char)('0' + value);
            }
            else if (value >= 10 && value <= 35)
            {
                return (char)('A' + value - 10);
            }
            return '?';
        }

        static string ConvertBase(string number, int fromBase, int toBase)
        {

            long decimalValue = 0;

            for (int i = 0; i < number.Length; i++)
            {
                int digitValue = CharToValue(number[i]);
                decimalValue = decimalValue * fromBase + digitValue;
            }

            if (toBase == 10)
            {
                return decimalValue.ToString();
            }

            if (decimalValue == 0)
            {
                return "0";
            }

            string result = "";
            long temp = decimalValue;

            while (temp > 0)
            {
                int remainder = (int)(temp % toBase);
                result = ValueToChar(remainder) + result;
                temp /= toBase;
            }

            return result;
        }
    }
}